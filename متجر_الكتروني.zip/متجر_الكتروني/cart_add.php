<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf_token($_POST['csrf_token'] ?? '')) {
    set_flash('error', 'طلب غير صالح.');
    header('Location: ' . base_url('index.php'));
    exit;
}

$product_id = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
$quantity   = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);

if (!$product_id || !$quantity || $quantity < 1) {
    set_flash('error', 'بيانات غير صحيحة.');
    header('Location: ' . base_url('index.php'));
    exit;
}

$stmt = $pdo->prepare('SELECT id, stock_quantity FROM products WHERE id = ?');
$stmt->execute([$product_id]);
$product = $stmt->fetch();

if (!$product) {
    set_flash('error', 'المنتج غير موجود.');
    header('Location: ' . base_url('index.php'));
    exit;
}

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$current_qty = $_SESSION['cart'][$product_id] ?? 0;
$new_qty = $current_qty + $quantity;

if ($new_qty > $product['stock_quantity']) {
    $new_qty = $product['stock_quantity'];
    set_flash('error', 'الكمية المطلوبة تتجاوز المتوفر بالمخزون، تم تعديلها للحد الأقصى المتاح.');
} else {
    set_flash('success', 'تمت إضافة المنتج إلى السلة.');
}

$_SESSION['cart'][$product_id] = $new_qty;

header('Location: ' . base_url('cart.php'));
exit;
