<?php
require_once __DIR__ . '/includes/functions.php';

if (is_logged_in()) {
    header('Location: ' . base_url(is_admin() ? 'admin/index.php' : 'index.php'));
    exit;
}

$errors = [];
$email = '';

// حماية بسيطة من محاولات الدخول المتكررة (Brute-force)
if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
    $_SESSION['login_block_until'] = 0;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (time() < $_SESSION['login_block_until']) {
        $errors[] = 'تم حظر تسجيل الدخول مؤقتاً بسبب محاولات فاشلة متكررة. حاول بعد دقيقة.';
    } elseif (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $errors[] = 'جلسة غير صالحة، الرجاء إعادة المحاولة.';
    } else {
        $email    = clean_input($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
            $errors[] = 'الرجاء إدخال بريد إلكتروني وكلمة مرور صحيحين.';
        } else {
            $stmt = $pdo->prepare('SELECT id, full_name, email, password, role, status FROM users WHERE email = ?');
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                if ($user['status'] === 'blocked') {
                    $errors[] = 'تم حظر هذا الحساب. تواصل مع الإدارة.';
                } else {
                    // نجاح تسجيل الدخول
                    session_regenerate_id(true); // منع Session Fixation
                    $_SESSION['user_id']   = $user['id'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['role']      = $user['role'];
                    $_SESSION['login_attempts'] = 0;

                    set_flash('success', 'مرحباً بك، ' . $user['full_name'] . '!');
                    header('Location: ' . base_url($user['role'] === 'admin' ? 'admin/index.php' : 'index.php'));
                    exit;
                }
            } else {
                $_SESSION['login_attempts']++;
                if ($_SESSION['login_attempts'] >= 5) {
                    $_SESSION['login_block_until'] = time() + 60;
                    $_SESSION['login_attempts'] = 0;
                }
                $errors[] = 'البريد الإلكتروني أو كلمة المرور غير صحيحة.';
            }
        }
    }
}

$page_title = 'تسجيل الدخول';
require_once __DIR__ . '/includes/header.php';
?>

<div class="card auth-card shadow-sm p-4">
  <h3 class="text-center mb-4"><i class="fa-solid fa-right-to-bracket"></i> تسجيل الدخول</h3>

  <?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
      <ul class="mb-0">
        <?php foreach ($errors as $err): ?>
          <li><?php echo htmlspecialchars($err); ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <form method="POST" novalidate>
    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">

    <div class="mb-3">
      <label class="form-label">البريد الإلكتروني</label>
      <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>" required>
    </div>

    <div class="mb-3">
      <label class="form-label">كلمة المرور</label>
      <input type="password" name="password" class="form-control" required>
    </div>

    <button type="submit" class="btn btn-primary w-100">دخول</button>
  </form>

  <p class="text-center mt-3 mb-0">ليس لديك حساب؟ <a href="<?php echo base_url('register.php'); ?>">إنشاء حساب جديد</a></p>

  <div class="alert alert-secondary mt-3 mb-0 small">
    <strong>للتجربة:</strong><br>
    مدير: admin@store.com / admin123<br>
    مستخدم: user@store.com / user123
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
