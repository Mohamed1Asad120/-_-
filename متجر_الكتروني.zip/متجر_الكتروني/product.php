<?php
require_once __DIR__ . '/includes/functions.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    set_flash('error', 'منتج غير موجود.');
    header('Location: ' . base_url('index.php'));
    exit;
}

$stmt = $pdo->prepare('SELECT p.*, c.name AS category_name FROM products p
                        LEFT JOIN categories c ON p.category_id = c.id WHERE p.id = ?');
$stmt->execute([$id]);
$product = $stmt->fetch();

if (!$product) {
    set_flash('error', 'المنتج المطلوب غير موجود.');
    header('Location: ' . base_url('index.php'));
    exit;
}

$page_title = $product['name'];
require_once __DIR__ . '/includes/header.php';
?>

<div class="row g-4">
  <div class="col-md-5">
    <img src="<?php echo base_url('uploads/products/' . htmlspecialchars($product['image'] ?: 'default.png')); ?>"
         class="img-fluid rounded shadow-sm" alt="<?php echo htmlspecialchars($product['name']); ?>">
  </div>
  <div class="col-md-7">
    <h3><?php echo htmlspecialchars($product['name']); ?></h3>
    <p class="text-muted"><?php echo htmlspecialchars($product['category_name'] ?? 'بدون تصنيف'); ?></p>
    <h4 class="text-primary mb-3"><?php echo format_price($product['price']); ?></h4>
    <p><?php echo nl2br(htmlspecialchars($product['description'])); ?></p>

    <?php if ($product['stock_quantity'] > 0): ?>
      <span class="badge bg-success mb-3">متوفر بالمخزون: <?php echo $product['stock_quantity']; ?></span>

      <form method="POST" action="<?php echo base_url('cart_add.php'); ?>" class="d-flex gap-2 align-items-center mt-2">
        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
        <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
        <input type="number" name="quantity" value="1" min="1" max="<?php echo $product['stock_quantity']; ?>" class="form-control" style="width:100px">
        <button type="submit" class="btn btn-primary"><i class="fa-solid fa-cart-plus"></i> أضف للسلة</button>
      </form>
    <?php else: ?>
      <span class="badge bg-secondary">غير متوفر حالياً</span>
    <?php endif; ?>

    <a href="<?php echo base_url('index.php'); ?>" class="btn btn-link mt-3">&larr; العودة للمنتجات</a>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
