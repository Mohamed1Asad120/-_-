<?php
require_once __DIR__ . '/includes/functions.php';

// إنهاء الجلسة بالكامل وحذف الكوكيز
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params['path'], $params['domain'], $params['secure'], $params['httponly']
    );
}
session_destroy();

session_start();
set_flash('success', 'تم تسجيل الخروج بنجاح.');
header('Location: ' . dirname($_SERVER['SCRIPT_NAME']) . '/login.php');
exit;
