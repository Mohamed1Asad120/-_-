-- ============================================
-- قاعدة بيانات مشروع "متجري الإلكتروني"
-- Mini Store Database
-- ============================================

CREATE DATABASE IF NOT EXISTS mini_store CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE mini_store;

-- ------------------------------------------------
-- جدول المستخدمين
-- ------------------------------------------------
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') NOT NULL DEFAULT 'user',
    status ENUM('active', 'blocked') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------
-- جدول تصنيفات المنتجات
-- ------------------------------------------------
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------
-- جدول المنتجات
-- ------------------------------------------------
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT DEFAULT NULL,
    name VARCHAR(150) NOT NULL,
    description TEXT DEFAULT NULL,
    price DECIMAL(10,2) NOT NULL,
    stock_quantity INT NOT NULL DEFAULT 0,
    image VARCHAR(255) DEFAULT 'default.png',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------
-- جدول الطلبات
-- ------------------------------------------------
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    shipping_address VARCHAR(255) NOT NULL,
    phone VARCHAR(30) NOT NULL,
    status ENUM('pending', 'processing', 'shipped', 'completed', 'cancelled') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------
-- جدول تفاصيل الطلب
-- ------------------------------------------------
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    product_name VARCHAR(150) NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB;

-- ============================================
-- بيانات أولية (Seed Data)
-- ============================================

-- حساب المدير: admin@store.com / admin123
-- حساب مستخدم تجريبي: user@store.com / user123
INSERT INTO users (full_name, email, password, role) VALUES
('مدير النظام', 'admin@store.com', '$2y$10$maR4su8VKoOWNC8mru.1G./bF.yxkNEcumKYrbjDAQkTlelPe1s3S', 'admin'),
('مستخدم تجريبي', 'user@store.com', '$2y$10$9alUtUMGels8gfGhyTUow.rg6RQo7anThTYUALJ9dr0.hOfAoWwku', 'user');

INSERT INTO categories (name, description) VALUES
('إلكترونيات', 'أجهزة إلكترونية ومستلزماتها'),
('ملابس', 'ملابس رجالية ونسائية'),
('أدوات منزلية', 'أدوات ومستلزمات المنزل');

INSERT INTO products (category_id, name, description, price, stock_quantity, image) VALUES
(1, 'سماعة بلوتوث', 'سماعة أذن لاسلكية عالية الجودة', 45.00, 25, 'default.png'),
(1, 'ساعة ذكية', 'ساعة ذكية بمزايا صحية متعددة', 120.00, 15, 'default.png'),
(2, 'قميص قطني', 'قميص رجالي قطني مريح', 20.00, 40, 'default.png'),
(3, 'خلاط كهربائي', 'خلاط كهربائي متعدد السرعات', 35.00, 10, 'default.png');
