<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

$stmt = $pdo->prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC');
$stmt->execute([$_SESSION['user_id']]);
$orders = $stmt->fetchAll();

$status_labels = [
    'pending'    => ['قيد الانتظار', 'secondary'],
    'processing' => ['قيد التجهيز', 'info'],
    'shipped'    => ['تم الشحن', 'primary'],
    'completed'  => ['مكتمل', 'success'],
    'cancelled'  => ['ملغي', 'danger'],
];

$page_title = 'طلباتي';
require_once __DIR__ . '/includes/header.php';
?>

<h3 class="mb-4"><i class="fa-solid fa-clock-rotate-left"></i> طلباتي</h3>

<?php if (empty($orders)): ?>
  <div class="alert alert-info">لا توجد طلبات سابقة.</div>
<?php else: ?>
  <div class="table-responsive">
    <table class="table bg-white shadow-sm rounded align-middle">
      <thead class="table-light">
        <tr>
          <th>رقم الطلب</th>
          <th>التاريخ</th>
          <th>الإجمالي</th>
          <th>الحالة</th>
          <th>التفاصيل</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($orders as $o): [$label, $color] = $status_labels[$o['status']]; ?>
          <tr>
            <td>#<?php echo $o['id']; ?></td>
            <td><?php echo date('Y-m-d H:i', strtotime($o['created_at'])); ?></td>
            <td><?php echo format_price($o['total_amount']); ?></td>
            <td><span class="badge bg-<?php echo $color; ?>"><?php echo $label; ?></span></td>
            <td>
              <button class="btn btn-sm btn-outline-primary" type="button" data-bs-toggle="collapse" data-bs-target="#order<?php echo $o['id']; ?>">
                عرض
              </button>
            </td>
          </tr>
          <tr class="collapse" id="order<?php echo $o['id']; ?>">
            <td colspan="5">
              <div class="p-3 bg-light rounded">
                <p class="mb-2"><strong>عنوان الشحن:</strong> <?php echo htmlspecialchars($o['shipping_address']); ?></p>
                <p class="mb-2"><strong>الهاتف:</strong> <?php echo htmlspecialchars($o['phone']); ?></p>
                <?php
                  $itemsStmt = $pdo->prepare('SELECT * FROM order_items WHERE order_id = ?');
                  $itemsStmt->execute([$o['id']]);
                  $items = $itemsStmt->fetchAll();
                ?>
                <ul class="mb-0">
                  <?php foreach ($items as $it): ?>
                    <li><?php echo htmlspecialchars($it['product_name']); ?> × <?php echo $it['quantity']; ?> — <?php echo format_price($it['price'] * $it['quantity']); ?></li>
                  <?php endforeach; ?>
                </ul>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
