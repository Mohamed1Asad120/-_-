<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

$order_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

$stmt = $pdo->prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?');
$stmt->execute([$order_id, $_SESSION['user_id']]);
$order = $stmt->fetch();

if (!$order) {
    header('Location: ' . base_url('index.php'));
    exit;
}

$page_title = 'تم تأكيد الطلب';
require_once __DIR__ . '/includes/header.php';
?>

<div class="text-center py-5">
  <i class="fa-solid fa-circle-check text-success" style="font-size:80px;"></i>
  <h3 class="mt-3">تم تأكيد طلبك بنجاح!</h3>
  <p class="text-muted">رقم الطلب: #<?php echo $order['id']; ?> — الإجمالي: <?php echo format_price($order['total_amount']); ?></p>
  <a href="<?php echo base_url('my_orders.php'); ?>" class="btn btn-primary">عرض طلباتي</a>
  <a href="<?php echo base_url('index.php'); ?>" class="btn btn-outline-secondary">متابعة التسوق</a>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
