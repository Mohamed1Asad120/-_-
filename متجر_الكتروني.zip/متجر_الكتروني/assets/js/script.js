// تأكيد الحذف قبل تنفيذه
document.addEventListener('click', function (e) {
    const btn = e.target.closest('.btn-confirm-delete');
    if (btn) {
        const msg = btn.dataset.confirm || 'هل أنت متأكد من الحذف؟ لا يمكن التراجع عن هذا الإجراء.';
        if (!confirm(msg)) {
            e.preventDefault();
        }
    }
});

// التحقق من تطابق كلمة المرور في نموذج التسجيل
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('registerForm');
    if (form) {
        form.addEventListener('submit', function (e) {
            const pass = document.getElementById('password').value;
            const confirm = document.getElementById('confirm_password').value;
            if (pass !== confirm) {
                e.preventDefault();
                alert('كلمة المرور وتأكيدها غير متطابقين.');
            }
            if (pass.length < 6) {
                e.preventDefault();
                alert('يجب ألا تقل كلمة المرور عن 6 أحرف.');
            }
        });
    }

    // معاينة الصورة قبل الرفع
    const imgInput = document.getElementById('image');
    const preview = document.getElementById('imagePreview');
    if (imgInput && preview) {
        imgInput.addEventListener('change', function () {
            const file = this.files[0];
            if (file) {
                preview.src = URL.createObjectURL(file);
                preview.classList.remove('d-none');
            }
        });
    }
});

// تحديث الكمية الإجمالية في السلة تلقائياً عند تغيير القيم (اختياري لتحسين التجربة)
function recalcCartTotal() {
    let total = 0;
    document.querySelectorAll('.cart-row').forEach(function (row) {
        const price = parseFloat(row.dataset.price);
        const qty = parseInt(row.querySelector('.qty-input').value, 10) || 0;
        total += price * qty;
        row.querySelector('.row-total').textContent = (price * qty).toFixed(2) + ' $';
    });
    const totalEl = document.getElementById('cartTotal');
    if (totalEl) totalEl.textContent = total.toFixed(2) + ' $';
}
