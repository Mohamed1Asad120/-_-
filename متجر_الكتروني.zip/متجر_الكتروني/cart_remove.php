<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

$product_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$token      = $_GET['csrf_token'] ?? '';

if ($product_id && verify_csrf_token($token) && isset($_SESSION['cart'][$product_id])) {
    unset($_SESSION['cart'][$product_id]);
    set_flash('success', 'تم حذف المنتج من السلة.');
} else {
    set_flash('error', 'تعذر حذف المنتج.');
}

header('Location: ' . base_url('cart.php'));
exit;
