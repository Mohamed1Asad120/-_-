<?php
require_once __DIR__ . '/includes/functions.php';

// إعادة توجيه المدير للوحة التحكم مباشرة
if (is_admin()) {
    header('Location: ' . base_url('admin/index.php'));
    exit;
}

$search      = clean_input($_GET['search'] ?? '');
$category_id = filter_input(INPUT_GET, 'category', FILTER_VALIDATE_INT);

$sql = 'SELECT p.*, c.name AS category_name FROM products p
        LEFT JOIN categories c ON p.category_id = c.id WHERE 1=1';
$params = [];

if ($search !== '') {
    $sql .= ' AND p.name LIKE ?';
    $params[] = '%' . $search . '%';
}
if ($category_id) {
    $sql .= ' AND p.category_id = ?';
    $params[] = $category_id;
}
$sql .= ' ORDER BY p.created_at DESC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

$categories = $pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll();

$page_title = 'المنتجات';
require_once __DIR__ . '/includes/header.php';
?>

<div class="row mb-4">
  <div class="col-12">
    <form method="GET" class="row g-2">
      <div class="col-md-6">
        <input type="text" name="search" class="form-control" placeholder="ابحث عن منتج..." value="<?php echo htmlspecialchars($search); ?>">
      </div>
      <div class="col-md-4">
        <select name="category" class="form-select">
          <option value="">كل التصنيفات</option>
          <?php foreach ($categories as $cat): ?>
            <option value="<?php echo $cat['id']; ?>" <?php echo ($category_id == $cat['id']) ? 'selected' : ''; ?>>
              <?php echo htmlspecialchars($cat['name']); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2">
        <button class="btn btn-primary w-100" type="submit"><i class="fa-solid fa-magnifying-glass"></i> بحث</button>
      </div>
    </form>
  </div>
</div>

<div class="row g-4">
  <?php if (empty($products)): ?>
    <div class="col-12">
      <div class="alert alert-info text-center">لا توجد منتجات مطابقة.</div>
    </div>
  <?php endif; ?>

  <?php foreach ($products as $p): ?>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <div class="card product-card h-100">
        <img src="<?php echo base_url('uploads/products/' . htmlspecialchars($p['image'] ?: 'default.png')); ?>"
             onerror="this.src='<?php echo base_url('assets/img/default.png'); ?>'" alt="<?php echo htmlspecialchars($p['name']); ?>">
        <div class="card-body d-flex flex-column">
          <h6 class="card-title mb-1"><?php echo htmlspecialchars($p['name']); ?></h6>
          <small class="text-muted mb-2"><?php echo htmlspecialchars($p['category_name'] ?? 'بدون تصنيف'); ?></small>
          <p class="fw-bold text-primary mb-2"><?php echo format_price($p['price']); ?></p>
          <?php if ($p['stock_quantity'] > 0): ?>
            <span class="badge bg-success badge-stock mb-2 align-self-start">متوفر (<?php echo $p['stock_quantity']; ?>)</span>
          <?php else: ?>
            <span class="badge bg-secondary badge-stock mb-2 align-self-start">غير متوفر</span>
          <?php endif; ?>
          <a href="<?php echo base_url('product.php?id=' . $p['id']); ?>" class="btn btn-outline-primary mt-auto btn-sm">عرض التفاصيل</a>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
