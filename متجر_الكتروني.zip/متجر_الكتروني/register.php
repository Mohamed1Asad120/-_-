<?php
require_once __DIR__ . '/includes/functions.php';

if (is_logged_in()) {
    header('Location: ' . base_url('index.php'));
    exit;
}

$errors = [];
$full_name = $email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $errors[] = 'جلسة غير صالحة، الرجاء إعادة المحاولة.';
    }

    $full_name = clean_input($_POST['full_name'] ?? '');
    $email     = clean_input($_POST['email'] ?? '');
    $password  = $_POST['password'] ?? '';
    $confirm   = $_POST['confirm_password'] ?? '';

    // ------------ التحقق من صحة المدخلات (Validation) ------------
    if ($full_name === '' || mb_strlen($full_name) < 3) {
        $errors[] = 'الاسم الكامل يجب ألا يقل عن 3 أحرف.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'صيغة البريد الإلكتروني غير صحيحة.';
    }
    if (strlen($password) < 6) {
        $errors[] = 'كلمة المرور يجب ألا تقل عن 6 أحرف.';
    }
    if ($password !== $confirm) {
        $errors[] = 'كلمة المرور وتأكيدها غير متطابقين.';
    }

    if (empty($errors)) {
        // التحقق من عدم تكرار البريد الإلكتروني
        $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = 'هذا البريد الإلكتروني مسجل مسبقاً.';
        }
    }

    if (empty($errors)) {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, "user")');
        $stmt->execute([$full_name, $email, $hashed]);

        set_flash('success', 'تم إنشاء الحساب بنجاح، يمكنك تسجيل الدخول الآن.');
        header('Location: ' . base_url('login.php'));
        exit;
    }
}

$page_title = 'إنشاء حساب';
require_once __DIR__ . '/includes/header.php';
?>

<div class="card auth-card shadow-sm p-4">
  <h3 class="text-center mb-4"><i class="fa-solid fa-user-plus"></i> إنشاء حساب جديد</h3>

  <?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
      <ul class="mb-0">
        <?php foreach ($errors as $err): ?>
          <li><?php echo htmlspecialchars($err); ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <form method="POST" id="registerForm" novalidate>
    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">

    <div class="mb-3">
      <label class="form-label">الاسم الكامل</label>
      <input type="text" name="full_name" class="form-control" value="<?php echo htmlspecialchars($full_name); ?>" required>
    </div>

    <div class="mb-3">
      <label class="form-label">البريد الإلكتروني</label>
      <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>" required>
    </div>

    <div class="mb-3">
      <label class="form-label">كلمة المرور</label>
      <input type="password" id="password" name="password" class="form-control" required>
    </div>

    <div class="mb-3">
      <label class="form-label">تأكيد كلمة المرور</label>
      <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
    </div>

    <button type="submit" class="btn btn-primary w-100">إنشاء الحساب</button>
  </form>

  <p class="text-center mt-3 mb-0">لديك حساب بالفعل؟ <a href="<?php echo base_url('login.php'); ?>">تسجيل الدخول</a></p>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
