<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

$cart_items = [];
$total = 0;

if (!empty($_SESSION['cart'])) {
    $ids = array_keys($_SESSION['cart']);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
    $stmt->execute($ids);
    $products = $stmt->fetchAll();

    foreach ($products as $p) {
        $qty = $_SESSION['cart'][$p['id']];
        $subtotal = $p['price'] * $qty;
        $total += $subtotal;
        $cart_items[] = [
            'product'  => $p,
            'qty'      => $qty,
            'subtotal' => $subtotal,
        ];
    }
}

$page_title = 'سلة التسوق';
require_once __DIR__ . '/includes/header.php';
?>

<h3 class="mb-4"><i class="fa-solid fa-cart-shopping"></i> سلة التسوق</h3>

<?php if (empty($cart_items)): ?>
  <div class="alert alert-info">سلتك فارغة حالياً. <a href="<?php echo base_url('index.php'); ?>">تصفح المنتجات</a></div>
<?php else: ?>

  <form method="POST" action="<?php echo base_url('cart_update.php'); ?>">
    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
    <div class="table-responsive">
      <table class="table align-middle bg-white shadow-sm rounded">
        <thead class="table-light">
          <tr>
            <th>المنتج</th>
            <th>السعر</th>
            <th>الكمية</th>
            <th>الإجمالي</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($cart_items as $item): $p = $item['product']; ?>
            <tr>
              <td class="d-flex align-items-center gap-2">
                <img src="<?php echo base_url('uploads/products/' . htmlspecialchars($p['image'] ?: 'default.png')); ?>" class="table-img">
                <?php echo htmlspecialchars($p['name']); ?>
              </td>
              <td><?php echo format_price($p['price']); ?></td>
              <td style="width:110px">
                <input type="number" name="quantity[<?php echo $p['id']; ?>]" value="<?php echo $item['qty']; ?>" min="0" max="<?php echo $p['stock_quantity']; ?>" class="form-control">
              </td>
              <td><?php echo format_price($item['subtotal']); ?></td>
              <td>
                <a href="<?php echo base_url('cart_remove.php?id=' . $p['id'] . '&csrf_token=' . generate_csrf_token()); ?>"
                   class="btn btn-sm btn-outline-danger btn-confirm-delete" data-confirm="حذف هذا المنتج من السلة؟">
                  <i class="fa-solid fa-trash"></i>
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="d-flex justify-content-between align-items-center">
      <button type="submit" class="btn btn-outline-secondary"><i class="fa-solid fa-rotate"></i> تحديث السلة</button>
      <h4>الإجمالي: <span class="text-primary"><?php echo format_price($total); ?></span></h4>
    </div>
  </form>

  <div class="text-end mt-3">
    <a href="<?php echo base_url('checkout.php'); ?>" class="btn btn-success btn-lg"><i class="fa-solid fa-credit-card"></i> إتمام الشراء</a>
  </div>

<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
