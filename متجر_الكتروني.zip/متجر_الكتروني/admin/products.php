<?php
$page_title = 'المنتجات';
require_once __DIR__ . '/admin_header.php';

$products = $pdo->query('SELECT p.*, c.name AS category_name FROM products p
                          LEFT JOIN categories c ON p.category_id = c.id
                          ORDER BY p.created_at DESC')->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
  <h3>إدارة المنتجات</h3>
  <a href="<?php echo base_url('admin/product_form.php'); ?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> إضافة منتج</a>
</div>

<div class="table-responsive">
  <table class="table bg-white shadow-sm rounded align-middle">
    <thead class="table-light">
      <tr>
        <th>الصورة</th><th>الاسم</th><th>التصنيف</th><th>السعر</th><th>المخزون</th><th>إجراءات</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($products as $p): ?>
        <tr>
          <td><img src="<?php echo base_url('uploads/products/' . htmlspecialchars($p['image'] ?: 'default.png')); ?>" class="table-img"></td>
          <td><?php echo htmlspecialchars($p['name']); ?></td>
          <td><?php echo htmlspecialchars($p['category_name'] ?? 'بدون تصنيف'); ?></td>
          <td><?php echo format_price($p['price']); ?></td>
          <td>
            <?php if ($p['stock_quantity'] <= 5): ?>
              <span class="badge bg-danger"><?php echo $p['stock_quantity']; ?></span>
            <?php else: ?>
              <span class="badge bg-success"><?php echo $p['stock_quantity']; ?></span>
            <?php endif; ?>
          </td>
          <td>
            <a href="<?php echo base_url('admin/product_form.php?id=' . $p['id']); ?>" class="btn btn-sm btn-outline-secondary"><i class="fa-solid fa-pen"></i></a>
            <a href="<?php echo base_url('admin/product_delete.php?id=' . $p['id'] . '&csrf_token=' . generate_csrf_token()); ?>"
               class="btn btn-sm btn-outline-danger btn-confirm-delete" data-confirm="هل تريد حذف هذا المنتج؟">
              <i class="fa-solid fa-trash"></i>
            </a>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($products)): ?>
        <tr><td colspan="6" class="text-center text-muted py-3">لا توجد منتجات بعد</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/admin_footer.php'; ?>
