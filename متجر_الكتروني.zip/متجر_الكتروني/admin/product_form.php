<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$product = [
    'id' => null, 'name' => '', 'description' => '', 'price' => '',
    'stock_quantity' => '', 'category_id' => '', 'image' => null,
];
$is_edit = false;

if ($id) {
    $stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
    $stmt->execute([$id]);
    $found = $stmt->fetch();
    if ($found) {
        $product = $found;
        $is_edit = true;
    }
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $errors[] = 'جلسة غير صالحة، الرجاء إعادة المحاولة.';
    }

    $name           = clean_input($_POST['name'] ?? '');
    $description    = clean_input($_POST['description'] ?? '');
    $price          = $_POST['price'] ?? '';
    $stock_quantity = $_POST['stock_quantity'] ?? '';
    $category_id    = filter_input(INPUT_POST, 'category_id', FILTER_VALIDATE_INT) ?: null;

    // ------------- التحقق من صحة المدخلات -------------
    if (mb_strlen($name) < 2) {
        $errors[] = 'اسم المنتج يجب ألا يقل عن حرفين.';
    }
    if (!is_numeric($price) || $price < 0) {
        $errors[] = 'السعر يجب أن يكون رقماً موجباً.';
    }
    if (!is_numeric($stock_quantity) || $stock_quantity < 0 || (int)$stock_quantity != $stock_quantity) {
        $errors[] = 'الكمية يجب أن تكون عدداً صحيحاً غير سالب.';
    }

    $image_filename = $product['image'];
    if (!empty($_FILES['image']['name'])) {
        $upload = upload_product_image($_FILES['image']);
        if (!$upload['success']) {
            $errors[] = $upload['message'];
        } elseif ($upload['filename']) {
            $image_filename = $upload['filename'];
        }
    }

    if (empty($errors)) {
        if ($is_edit) {
            $stmt = $pdo->prepare('UPDATE products SET name=?, description=?, price=?, stock_quantity=?, category_id=?, image=? WHERE id=?');
            $stmt->execute([$name, $description, $price, $stock_quantity, $category_id, $image_filename, $id]);
            set_flash('success', 'تم تحديث المنتج بنجاح.');
        } else {
            $stmt = $pdo->prepare('INSERT INTO products (name, description, price, stock_quantity, category_id, image) VALUES (?, ?, ?, ?, ?, ?)');
            $stmt->execute([$name, $description, $price, $stock_quantity, $category_id, $image_filename ?: 'default.png']);
            set_flash('success', 'تمت إضافة المنتج بنجاح.');
        }
        header('Location: ' . base_url('admin/products.php'));
        exit;
    }

    // في حال وجود أخطاء، نُبقي القيم المُدخلة لعرضها للمستخدم
    $product = array_merge($product, [
        'name' => $name, 'description' => $description, 'price' => $price,
        'stock_quantity' => $stock_quantity, 'category_id' => $category_id,
    ]);
}

$categories = $pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll();

$page_title = $is_edit ? 'تعديل منتج' : 'إضافة منتج';
require_once __DIR__ . '/admin_header.php';
?>

<h3 class="mb-4"><?php echo $is_edit ? 'تعديل منتج' : 'إضافة منتج جديد'; ?></h3>

<?php if (!empty($errors)): ?>
  <div class="alert alert-danger">
    <ul class="mb-0"><?php foreach ($errors as $e): ?><li><?php echo htmlspecialchars($e); ?></li><?php endforeach; ?></ul>
  </div>
<?php endif; ?>

<div class="card shadow-sm p-4" style="max-width:700px;">
  <form method="POST" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">

    <div class="mb-3">
      <label class="form-label">اسم المنتج</label>
      <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($product['name']); ?>" required>
    </div>

    <div class="mb-3">
      <label class="form-label">الوصف</label>
      <textarea name="description" class="form-control" rows="3"><?php echo htmlspecialchars($product['description']); ?></textarea>
    </div>

    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">السعر ($)</label>
        <input type="number" step="0.01" min="0" name="price" class="form-control" value="<?php echo htmlspecialchars($product['price']); ?>" required>
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">الكمية بالمخزون</label>
        <input type="number" min="0" name="stock_quantity" class="form-control" value="<?php echo htmlspecialchars($product['stock_quantity']); ?>" required>
      </div>
    </div>

    <div class="mb-3">
      <label class="form-label">التصنيف</label>
      <select name="category_id" class="form-select">
        <option value="">بدون تصنيف</option>
        <?php foreach ($categories as $cat): ?>
          <option value="<?php echo $cat['id']; ?>" <?php echo ($product['category_id'] == $cat['id']) ? 'selected' : ''; ?>>
            <?php echo htmlspecialchars($cat['name']); ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="mb-3">
      <label class="form-label">صورة المنتج</label>
      <input type="file" id="image" name="image" class="form-control" accept=".jpg,.jpeg,.png,.webp">
      <?php if ($product['image']): ?>
        <img src="<?php echo base_url('uploads/products/' . htmlspecialchars($product['image'])); ?>" id="imagePreview" class="mt-2 rounded" style="max-height:120px;">
      <?php else: ?>
        <img id="imagePreview" class="mt-2 rounded d-none" style="max-height:120px;">
      <?php endif; ?>
    </div>

    <button type="submit" class="btn btn-primary"><?php echo $is_edit ? 'حفظ التعديلات' : 'إضافة المنتج'; ?></button>
    <a href="<?php echo base_url('admin/products.php'); ?>" class="btn btn-outline-secondary">إلغاء</a>
  </form>
</div>

<?php require_once __DIR__ . '/admin_footer.php'; ?>
