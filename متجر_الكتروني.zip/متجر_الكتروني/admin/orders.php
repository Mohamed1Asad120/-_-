<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$valid_statuses = ['pending', 'processing', 'shipped', 'completed', 'cancelled'];

// تحديث حالة الطلب
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('error', 'جلسة غير صالحة.');
    } else {
        $order_id = filter_input(INPUT_POST, 'order_id', FILTER_VALIDATE_INT);
        $status   = $_POST['status'] ?? '';
        if ($order_id && in_array($status, $valid_statuses, true)) {
            $stmt = $pdo->prepare('UPDATE orders SET status = ? WHERE id = ?');
            $stmt->execute([$status, $order_id]);
            set_flash('success', 'تم تحديث حالة الطلب.');
        } else {
            set_flash('error', 'بيانات غير صحيحة.');
        }
    }
    header('Location: ' . base_url('admin/orders.php'));
    exit;
}

$filter_status = $_GET['status'] ?? '';
$sql = "SELECT o.*, u.full_name, u.email FROM orders o JOIN users u ON o.user_id = u.id WHERE 1=1";
$params = [];
if (in_array($filter_status, $valid_statuses, true)) {
    $sql .= ' AND o.status = ?';
    $params[] = $filter_status;
}
$sql .= ' ORDER BY o.created_at DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

$status_labels = [
    'pending'    => ['قيد الانتظار', 'secondary'],
    'processing' => ['قيد التجهيز', 'info'],
    'shipped'    => ['تم الشحن', 'primary'],
    'completed'  => ['مكتمل', 'success'],
    'cancelled'  => ['ملغي', 'danger'],
];

$page_title = 'الطلبات';
require_once __DIR__ . '/admin_header.php';
?>

<h3 class="mb-4">إدارة الطلبات</h3>

<form method="GET" class="mb-3 col-md-3">
  <select name="status" class="form-select" onchange="this.form.submit()">
    <option value="">كل الحالات</option>
    <?php foreach ($status_labels as $key => [$label, $color]): ?>
      <option value="<?php echo $key; ?>" <?php echo $filter_status === $key ? 'selected' : ''; ?>><?php echo $label; ?></option>
    <?php endforeach; ?>
  </select>
</form>

<div class="table-responsive">
  <table class="table bg-white shadow-sm rounded align-middle">
    <thead class="table-light">
      <tr><th>#</th><th>العميل</th><th>الإجمالي</th><th>العنوان</th><th>التاريخ</th><th>الحالة</th><th>تحديث</th></tr>
    </thead>
    <tbody>
      <?php foreach ($orders as $o): [$label, $color] = $status_labels[$o['status']]; ?>
        <tr>
          <td>#<?php echo $o['id']; ?></td>
          <td><?php echo htmlspecialchars($o['full_name']); ?><br><small class="text-muted"><?php echo htmlspecialchars($o['email']); ?></small></td>
          <td><?php echo format_price($o['total_amount']); ?></td>
          <td><?php echo htmlspecialchars($o['shipping_address']); ?></td>
          <td><?php echo date('Y-m-d', strtotime($o['created_at'])); ?></td>
          <td><span class="badge bg-<?php echo $color; ?>"><?php echo $label; ?></span></td>
          <td>
            <form method="POST" class="d-flex gap-1">
              <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
              <input type="hidden" name="order_id" value="<?php echo $o['id']; ?>">
              <select name="status" class="form-select form-select-sm">
                <?php foreach ($status_labels as $key => [$lbl, $c]): ?>
                  <option value="<?php echo $key; ?>" <?php echo $o['status'] === $key ? 'selected' : ''; ?>><?php echo $lbl; ?></option>
                <?php endforeach; ?>
              </select>
              <button type="submit" name="update_status" class="btn btn-sm btn-primary">حفظ</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($orders)): ?>
        <tr><td colspan="7" class="text-center text-muted py-3">لا توجد طلبات</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/admin_footer.php'; ?>
