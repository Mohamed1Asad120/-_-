<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$errors = [];
$edit_category = ['id' => null, 'name' => '', 'description' => ''];

// حذف تصنيف
if (isset($_GET['delete'])) {
    $del_id = filter_input(INPUT_GET, 'delete', FILTER_VALIDATE_INT);
    if ($del_id && verify_csrf_token($_GET['csrf_token'] ?? '')) {
        $stmt = $pdo->prepare('DELETE FROM categories WHERE id = ?');
        $stmt->execute([$del_id]);
        set_flash('success', 'تم حذف التصنيف بنجاح.');
    }
    header('Location: ' . base_url('admin/categories.php'));
    exit;
}

// تحميل بيانات تصنيف للتعديل
if (isset($_GET['edit'])) {
    $edit_id = filter_input(INPUT_GET, 'edit', FILTER_VALIDATE_INT);
    $stmt = $pdo->prepare('SELECT * FROM categories WHERE id = ?');
    $stmt->execute([$edit_id]);
    $found = $stmt->fetch();
    if ($found) $edit_category = $found;
}

// إضافة / تعديل
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $errors[] = 'جلسة غير صالحة، الرجاء إعادة المحاولة.';
    }

    $name = clean_input($_POST['name'] ?? '');
    $description = clean_input($_POST['description'] ?? '');
    $cat_id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

    if (mb_strlen($name) < 2) {
        $errors[] = 'اسم التصنيف يجب ألا يقل عن حرفين.';
    }

    if (empty($errors)) {
        if ($cat_id) {
            $stmt = $pdo->prepare('UPDATE categories SET name=?, description=? WHERE id=?');
            $stmt->execute([$name, $description, $cat_id]);
            set_flash('success', 'تم تحديث التصنيف بنجاح.');
        } else {
            $stmt = $pdo->prepare('INSERT INTO categories (name, description) VALUES (?, ?)');
            $stmt->execute([$name, $description]);
            set_flash('success', 'تمت إضافة التصنيف بنجاح.');
        }
        header('Location: ' . base_url('admin/categories.php'));
        exit;
    }
    $edit_category = ['id' => $cat_id, 'name' => $name, 'description' => $description];
}

$categories = $pdo->query('SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) AS product_count
                            FROM categories c ORDER BY c.name')->fetchAll();

$page_title = 'التصنيفات';
require_once __DIR__ . '/admin_header.php';
?>

<h3 class="mb-4">إدارة التصنيفات</h3>

<?php if (!empty($errors)): ?>
  <div class="alert alert-danger">
    <ul class="mb-0"><?php foreach ($errors as $e): ?><li><?php echo htmlspecialchars($e); ?></li><?php endforeach; ?></ul>
  </div>
<?php endif; ?>

<div class="row g-4">
  <div class="col-md-4">
    <div class="card shadow-sm p-3">
      <h5><?php echo $edit_category['id'] ? 'تعديل تصنيف' : 'إضافة تصنيف'; ?></h5>
      <form method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($edit_category['id'] ?? ''); ?>">
        <div class="mb-2">
          <label class="form-label">اسم التصنيف</label>
          <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($edit_category['name']); ?>" required>
        </div>
        <div class="mb-2">
          <label class="form-label">الوصف</label>
          <textarea name="description" class="form-control" rows="2"><?php echo htmlspecialchars($edit_category['description']); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary w-100"><?php echo $edit_category['id'] ? 'حفظ التعديلات' : 'إضافة'; ?></button>
        <?php if ($edit_category['id']): ?>
          <a href="<?php echo base_url('admin/categories.php'); ?>" class="btn btn-outline-secondary w-100 mt-2">إلغاء التعديل</a>
        <?php endif; ?>
      </form>
    </div>
  </div>

  <div class="col-md-8">
    <div class="table-responsive">
      <table class="table bg-white shadow-sm rounded align-middle">
        <thead class="table-light"><tr><th>الاسم</th><th>الوصف</th><th>عدد المنتجات</th><th>إجراءات</th></tr></thead>
        <tbody>
          <?php foreach ($categories as $cat): ?>
            <tr>
              <td><?php echo htmlspecialchars($cat['name']); ?></td>
              <td><?php echo htmlspecialchars($cat['description']); ?></td>
              <td><span class="badge bg-info"><?php echo $cat['product_count']; ?></span></td>
              <td>
                <a href="<?php echo base_url('admin/categories.php?edit=' . $cat['id']); ?>" class="btn btn-sm btn-outline-secondary"><i class="fa-solid fa-pen"></i></a>
                <a href="<?php echo base_url('admin/categories.php?delete=' . $cat['id'] . '&csrf_token=' . generate_csrf_token()); ?>"
                   class="btn btn-sm btn-outline-danger btn-confirm-delete" data-confirm="حذف هذا التصنيف؟ المنتجات المرتبطة ستصبح بدون تصنيف.">
                  <i class="fa-solid fa-trash"></i>
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
          <?php if (empty($categories)): ?>
            <tr><td colspan="4" class="text-center text-muted py-3">لا توجد تصنيفات بعد</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/admin_footer.php'; ?>
