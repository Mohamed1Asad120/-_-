<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

// تفعيل / حظر مستخدم
if (isset($_GET['toggle'])) {
    $uid = filter_input(INPUT_GET, 'toggle', FILTER_VALIDATE_INT);
    if ($uid && $uid != $_SESSION['user_id'] && verify_csrf_token($_GET['csrf_token'] ?? '')) {
        $stmt = $pdo->prepare('SELECT status, role FROM users WHERE id = ?');
        $stmt->execute([$uid]);
        $u = $stmt->fetch();
        if ($u && $u['role'] !== 'admin') {
            $new_status = $u['status'] === 'active' ? 'blocked' : 'active';
            $stmt = $pdo->prepare('UPDATE users SET status = ? WHERE id = ?');
            $stmt->execute([$new_status, $uid]);
            set_flash('success', 'تم تحديث حالة المستخدم.');
        }
    }
    header('Location: ' . base_url('admin/users.php'));
    exit;
}

$users = $pdo->query("SELECT * FROM users WHERE role = 'user' ORDER BY created_at DESC")->fetchAll();

$page_title = 'المستخدمين';
require_once __DIR__ . '/admin_header.php';
?>

<h3 class="mb-4">إدارة المستخدمين</h3>

<div class="table-responsive">
  <table class="table bg-white shadow-sm rounded align-middle">
    <thead class="table-light"><tr><th>الاسم</th><th>البريد الإلكتروني</th><th>تاريخ التسجيل</th><th>الحالة</th><th>إجراءات</th></tr></thead>
    <tbody>
      <?php foreach ($users as $u): ?>
        <tr>
          <td><?php echo htmlspecialchars($u['full_name']); ?></td>
          <td><?php echo htmlspecialchars($u['email']); ?></td>
          <td><?php echo date('Y-m-d', strtotime($u['created_at'])); ?></td>
          <td>
            <?php if ($u['status'] === 'active'): ?>
              <span class="badge bg-success">مفعل</span>
            <?php else: ?>
              <span class="badge bg-danger">محظور</span>
            <?php endif; ?>
          </td>
          <td>
            <a href="<?php echo base_url('admin/users.php?toggle=' . $u['id'] . '&csrf_token=' . generate_csrf_token()); ?>"
               class="btn btn-sm <?php echo $u['status'] === 'active' ? 'btn-outline-danger' : 'btn-outline-success'; ?> btn-confirm-delete"
               data-confirm="هل تريد تغيير حالة هذا المستخدم؟">
              <?php echo $u['status'] === 'active' ? 'حظر' : 'تفعيل'; ?>
            </a>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($users)): ?>
        <tr><td colspan="5" class="text-center text-muted py-3">لا يوجد مستخدمون بعد</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/admin_footer.php'; ?>
