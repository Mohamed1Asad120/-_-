<?php
$page_title = 'الرئيسية';
require_once __DIR__ . '/admin_header.php';

$total_products   = $pdo->query('SELECT COUNT(*) FROM products')->fetchColumn();
$total_orders     = $pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn();
$total_users      = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'user'")->fetchColumn();
$total_sales      = $pdo->query("SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE status != 'cancelled'")->fetchColumn();
$pending_orders   = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'pending'")->fetchColumn();
$low_stock        = $pdo->query('SELECT * FROM products WHERE stock_quantity <= 5 ORDER BY stock_quantity ASC LIMIT 5')->fetchAll();
$recent_orders    = $pdo->query('SELECT o.*, u.full_name FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 5')->fetchAll();
?>

<h3 class="mb-4">لوحة المعلومات</h3>

<div class="row g-3 mb-4">
  <div class="col-md-3">
    <div class="dashboard-stat stat-blue">
      <div class="small">إجمالي المنتجات</div>
      <div class="fs-3 fw-bold"><?php echo $total_products; ?></div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="dashboard-stat stat-green">
      <div class="small">إجمالي الطلبات</div>
      <div class="fs-3 fw-bold"><?php echo $total_orders; ?></div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="dashboard-stat stat-orange">
      <div class="small">إجمالي المستخدمين</div>
      <div class="fs-3 fw-bold"><?php echo $total_users; ?></div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="dashboard-stat stat-red">
      <div class="small">إجمالي المبيعات</div>
      <div class="fs-3 fw-bold"><?php echo format_price($total_sales); ?></div>
    </div>
  </div>
</div>

<div class="row g-4">
  <div class="col-md-7">
    <div class="card shadow-sm p-3">
      <h5 class="mb-3">أحدث الطلبات <?php if ($pending_orders): ?><span class="badge bg-warning text-dark"><?php echo $pending_orders; ?> بانتظار المعالجة</span><?php endif; ?></h5>
      <table class="table table-sm align-middle">
        <thead><tr><th>#</th><th>العميل</th><th>الإجمالي</th><th>الحالة</th></tr></thead>
        <tbody>
        <?php foreach ($recent_orders as $o): ?>
          <tr>
            <td>#<?php echo $o['id']; ?></td>
            <td><?php echo htmlspecialchars($o['full_name']); ?></td>
            <td><?php echo format_price($o['total_amount']); ?></td>
            <td><?php echo htmlspecialchars($o['status']); ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if (empty($recent_orders)): ?>
          <tr><td colspan="4" class="text-center text-muted">لا توجد طلبات بعد</td></tr>
        <?php endif; ?>
        </tbody>
      </table>
      <a href="<?php echo base_url('admin/orders.php'); ?>" class="btn btn-sm btn-outline-primary">عرض جميع الطلبات</a>
    </div>
  </div>

  <div class="col-md-5">
    <div class="card shadow-sm p-3">
      <h5 class="mb-3">منتجات بمخزون منخفض</h5>
      <ul class="list-group">
        <?php foreach ($low_stock as $p): ?>
          <li class="list-group-item d-flex justify-content-between align-items-center">
            <?php echo htmlspecialchars($p['name']); ?>
            <span class="badge bg-danger"><?php echo $p['stock_quantity']; ?> متبقي</span>
          </li>
        <?php endforeach; ?>
        <?php if (empty($low_stock)): ?>
          <li class="list-group-item text-muted text-center">لا توجد منتجات منخفضة المخزون</li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/admin_footer.php'; ?>
