<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$flash = get_flash();
$current = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($page_title) ? htmlspecialchars($page_title) . ' - لوحة التحكم' : 'لوحة التحكم'; ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold" href="<?php echo base_url('admin/index.php'); ?>">
      <i class="fa-solid fa-store"></i> لوحة تحكم المدير
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav ms-auto align-items-lg-center">
        <li class="nav-item"><a class="nav-link" href="<?php echo base_url('index.php'); ?>" target="_blank"><i class="fa-solid fa-shop"></i> عرض المتجر</a></li>
        <li class="nav-item"><span class="nav-link">مرحباً، <?php echo htmlspecialchars($_SESSION['full_name']); ?></span></li>
        <li class="nav-item"><a class="nav-link" href="<?php echo base_url('logout.php'); ?>"><i class="fa-solid fa-right-from-bracket"></i> خروج</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="d-flex">
  <div class="sidebar" style="width:230px; min-width:230px;">
    <a href="<?php echo base_url('admin/index.php'); ?>" class="<?php echo $current === 'index.php' ? 'active' : ''; ?>"><i class="fa-solid fa-gauge me-1"></i> الرئيسية</a>
    <a href="<?php echo base_url('admin/products.php'); ?>" class="<?php echo strpos($current, 'product') === 0 ? 'active' : ''; ?>"><i class="fa-solid fa-box me-1"></i> المنتجات</a>
    <a href="<?php echo base_url('admin/categories.php'); ?>" class="<?php echo strpos($current, 'categor') === 0 ? 'active' : ''; ?>"><i class="fa-solid fa-tags me-1"></i> التصنيفات</a>
    <a href="<?php echo base_url('admin/orders.php'); ?>" class="<?php echo strpos($current, 'order') === 0 ? 'active' : ''; ?>"><i class="fa-solid fa-receipt me-1"></i> الطلبات</a>
    <a href="<?php echo base_url('admin/users.php'); ?>" class="<?php echo strpos($current, 'user') === 0 ? 'active' : ''; ?>"><i class="fa-solid fa-users me-1"></i> المستخدمين</a>
  </div>

  <div class="flex-fill p-4">
    <?php if ($flash): ?>
      <?php foreach ($flash as $type => $msg): ?>
        <?php $alert_class = $type === 'error' ? 'danger' : ($type === 'success' ? 'success' : 'info'); ?>
        <div class="alert alert-<?php echo $alert_class; ?> alert-dismissible fade show" role="alert">
          <?php echo htmlspecialchars($msg); ?>
          <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
