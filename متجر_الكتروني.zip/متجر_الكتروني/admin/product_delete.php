<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$id    = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$token = $_GET['csrf_token'] ?? '';

if ($id && verify_csrf_token($token)) {
    // حذف صورة المنتج من الخادم إن وجدت (وليست الصورة الافتراضية)
    $stmt = $pdo->prepare('SELECT image FROM products WHERE id = ?');
    $stmt->execute([$id]);
    $image = $stmt->fetchColumn();
    if ($image && $image !== 'default.png') {
        $path = __DIR__ . '/../uploads/products/' . $image;
        if (is_file($path)) {
            @unlink($path);
        }
    }

    $stmt = $pdo->prepare('DELETE FROM products WHERE id = ?');
    $stmt->execute([$id]);
    set_flash('success', 'تم حذف المنتج بنجاح.');
} else {
    set_flash('error', 'تعذر حذف المنتج.');
}

header('Location: ' . base_url('admin/products.php'));
exit;
