<?php
/**
 * دوال مساعدة عامة يستخدمها المشروع بالكامل
 */

if (session_status() === PHP_SESSION_NONE) {
    // إعدادات أمان الجلسة (Session Security)
    ini_set('session.cookie_httponly', 1); // منع الوصول للكوكيز عبر JavaScript
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    session_start();
}

require_once __DIR__ . '/../config/database.php';

/* ------------------------------------------------
   تنظيف المدخلات (Input Sanitization)
------------------------------------------------ */
function clean_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

/* ------------------------------------------------
   حماية CSRF
------------------------------------------------ */
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_token($token) {
    if (empty($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/* ------------------------------------------------
   رسائل التأكيد / الخطأ (Flash Messages)
------------------------------------------------ */
function set_flash($type, $message) {
    $_SESSION['flash'][$type] = $message;
}

function get_flash() {
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}

/* ------------------------------------------------
   التحقق من تسجيل الدخول والصلاحيات
------------------------------------------------ */
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function is_admin() {
    return is_logged_in() && ($_SESSION['role'] ?? '') === 'admin';
}

function require_login() {
    if (!is_logged_in()) {
        set_flash('error', 'يجب تسجيل الدخول أولاً للوصول لهذه الصفحة.');
        header('Location: ' . base_url('login.php'));
        exit;
    }
}

function require_admin() {
    require_login();
    if (!is_admin()) {
        set_flash('error', 'ليس لديك صلاحية للوصول لهذه الصفحة.');
        header('Location: ' . base_url('index.php'));
        exit;
    }
}

/* ------------------------------------------------
   مسار أساسي للمشروع (لتسهيل الروابط بين المجلدات)
------------------------------------------------ */
function base_url($path = '') {
    // نحدد جذر المشروع بناءً على مجلد المشروع الحالي
    $root = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
    // إذا كنا داخل مجلد admin نرجع خطوة للخلف
    if (basename($root) === 'admin') {
        $root = dirname($root);
    }
    return $root . '/' . ltrim($path, '/');
}

/* ------------------------------------------------
   رفع الصور بأمان
------------------------------------------------ */
function upload_product_image($file) {
    $allowed_ext  = ['jpg', 'jpeg', 'png', 'webp'];
    $allowed_mime = ['image/jpeg', 'image/png', 'image/webp'];
    $max_size     = 3 * 1024 * 1024; // 3MB

    if (!isset($file) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return ['success' => true, 'filename' => null]; // لم يتم رفع صورة (اختياري)
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'حدث خطأ أثناء رفع الصورة.'];
    }

    if ($file['size'] > $max_size) {
        return ['success' => false, 'message' => 'حجم الصورة يجب ألا يتجاوز 3 ميجابايت.'];
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed_ext, true)) {
        return ['success' => false, 'message' => 'صيغة الصورة غير مسموحة. المسموح: jpg, jpeg, png, webp'];
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    if (!in_array($mime, $allowed_mime, true)) {
        return ['success' => false, 'message' => 'نوع الملف غير صالح.'];
    }

    // اسم فريد للملف لمنع الكتابة فوق ملفات أخرى أو تنفيذ أكواد
    $new_name = uniqid('prod_', true) . '.' . $ext;
    $target_dir = __DIR__ . '/../uploads/products/';
    $target_path = $target_dir . $new_name;

    if (!move_uploaded_file($file['tmp_name'], $target_path)) {
        return ['success' => false, 'message' => 'تعذر حفظ الصورة على الخادم.'];
    }

    return ['success' => true, 'filename' => $new_name];
}

/* ------------------------------------------------
   تنسيق السعر
------------------------------------------------ */
function format_price($price) {
    return number_format((float)$price, 2) . ' شيكل';
}
