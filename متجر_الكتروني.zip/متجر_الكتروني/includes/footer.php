</main>

<footer class="bg-dark text-light py-4 mt-auto">
  <div class="container text-center">
    <p class="mb-0">&copy; <?php echo date('Y'); ?> متجري الإلكتروني - جميع الحقوق محفوظة</p>
    <small class="text-secondary">مشروع نهائي - محمد اسعد الزقزوق  </small>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url('assets/js/script.js'); ?>"></script>
</body>
</html>
