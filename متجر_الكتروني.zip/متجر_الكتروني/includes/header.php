<?php
require_once __DIR__ . '/functions.php';
$flash = get_flash();
$cart_count = 0;
if (!empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $qty) {
        $cart_count += $qty;
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($page_title) ? htmlspecialchars($page_title) . ' - متجري الإلكتروني' : 'متجري الإلكتروني'; ?></title>
<!-- Bootstrap RTL -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
  <div class="container">
    <a class="navbar-brand fw-bold" href="<?php echo base_url('index.php'); ?>">
      <i class="fa-solid fa-store"></i> متجري الإلكتروني
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link" href="<?php echo base_url('index.php'); ?>">المنتجات</a></li>
        <?php if (is_logged_in() && !is_admin()): ?>
          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('my_orders.php'); ?>">طلباتي</a></li>
        <?php endif; ?>
        <?php if (is_admin()): ?>
          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/index.php'); ?>">لوحة التحكم</a></li>
        <?php endif; ?>
      </ul>
      <ul class="navbar-nav align-items-lg-center">
        <?php if (!is_admin()): ?>
        <li class="nav-item">
          <a class="nav-link position-relative" href="<?php echo base_url('cart.php'); ?>">
            <i class="fa-solid fa-cart-shopping"></i> السلة
            <?php if ($cart_count > 0): ?>
              <span class="badge rounded-pill bg-danger"><?php echo $cart_count; ?></span>
            <?php endif; ?>
          </a>
        </li>
        <?php endif; ?>
        <?php if (is_logged_in()): ?>
          <li class="nav-item"><span class="nav-link text-light-50">مرحباً، <?php echo htmlspecialchars($_SESSION['full_name']); ?></span></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('logout.php'); ?>"><i class="fa-solid fa-right-from-bracket"></i> تسجيل خروج</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('login.php'); ?>">تسجيل دخول</a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('register.php'); ?>">تسجيل جديد</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<div class="container mt-4">
  <?php if ($flash): ?>
    <?php foreach ($flash as $type => $msg): ?>
      <?php $alert_class = $type === 'error' ? 'danger' : ($type === 'success' ? 'success' : 'info'); ?>
      <div class="alert alert-<?php echo $alert_class; ?> alert-dismissible fade show" role="alert">
        <?php echo htmlspecialchars($msg); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<main class="container mb-5">
