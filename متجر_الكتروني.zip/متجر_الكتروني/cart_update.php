<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf_token($_POST['csrf_token'] ?? '')) {
    set_flash('error', 'طلب غير صالح.');
    header('Location: ' . base_url('cart.php'));
    exit;
}

$quantities = $_POST['quantity'] ?? [];

foreach ($quantities as $product_id => $qty) {
    $product_id = (int)$product_id;
    $qty = (int)$qty;

    if (!isset($_SESSION['cart'][$product_id])) continue;

    if ($qty <= 0) {
        unset($_SESSION['cart'][$product_id]);
        continue;
    }

    $stmt = $pdo->prepare('SELECT stock_quantity FROM products WHERE id = ?');
    $stmt->execute([$product_id]);
    $stock = (int)($stmt->fetchColumn() ?: 0);

    $_SESSION['cart'][$product_id] = min($qty, $stock);
}

set_flash('success', 'تم تحديث السلة.');
header('Location: ' . base_url('cart.php'));
exit;
