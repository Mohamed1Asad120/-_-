<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

if (empty($_SESSION['cart'])) {
    set_flash('error', 'سلتك فارغة.');
    header('Location: ' . base_url('cart.php'));
    exit;
}

$errors = [];
$address = $phone = '';

// جلب عناصر السلة الحالية لعرض الملخص
$ids = array_keys($_SESSION['cart']);
$placeholders = implode(',', array_fill(0, count($ids), '?'));
$stmt = $pdo->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
$stmt->execute($ids);
$products = $stmt->fetchAll();

$total = 0;
$cart_items = [];
foreach ($products as $p) {
    $qty = $_SESSION['cart'][$p['id']];
    $subtotal = $p['price'] * $qty;
    $total += $subtotal;
    $cart_items[] = ['product' => $p, 'qty' => $qty, 'subtotal' => $subtotal];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $errors[] = 'جلسة غير صالحة، الرجاء إعادة المحاولة.';
    }

    $address = clean_input($_POST['address'] ?? '');
    $phone   = clean_input($_POST['phone'] ?? '');

    if (mb_strlen($address) < 8) {
        $errors[] = 'الرجاء إدخال عنوان شحن تفصيلي (8 أحرف على الأقل).';
    }
    if (!preg_match('/^[0-9+\-\s]{7,20}$/', $phone)) {
        $errors[] = 'رقم الهاتف غير صحيح.';
    }

    if (empty($errors)) {
        try {
            $pdo->beginTransaction();

            // إعادة التحقق من توفر المخزون قبل تأكيد الطلب (لمنع تجاوز الكمية)
            foreach ($cart_items as $item) {
                $stmt = $pdo->prepare('SELECT stock_quantity FROM products WHERE id = ? FOR UPDATE');
                $stmt->execute([$item['product']['id']]);
                $stock = (int)$stmt->fetchColumn();
                if ($item['qty'] > $stock) {
                    throw new Exception('الكمية المطلوبة من "' . $item['product']['name'] . '" لم تعد متوفرة بالكامل.');
                }
            }

            $stmt = $pdo->prepare('INSERT INTO orders (user_id, total_amount, shipping_address, phone, status) VALUES (?, ?, ?, ?, "pending")');
            $stmt->execute([$_SESSION['user_id'], $total, $address, $phone]);
            $order_id = $pdo->lastInsertId();

            $itemStmt  = $pdo->prepare('INSERT INTO order_items (order_id, product_id, product_name, quantity, price) VALUES (?, ?, ?, ?, ?)');
            $stockStmt = $pdo->prepare('UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?');

            foreach ($cart_items as $item) {
                $itemStmt->execute([$order_id, $item['product']['id'], $item['product']['name'], $item['qty'], $item['product']['price']]);
                $stockStmt->execute([$item['qty'], $item['product']['id']]);
            }

            $pdo->commit();
            $_SESSION['cart'] = [];

            set_flash('success', 'تم تأكيد طلبك بنجاح! رقم الطلب: #' . $order_id);
            header('Location: ' . base_url('order_success.php?id=' . $order_id));
            exit;

        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = $e->getMessage();
        }
    }
}

$page_title = 'إتمام الشراء';
require_once __DIR__ . '/includes/header.php';
?>

<h3 class="mb-4"><i class="fa-solid fa-credit-card"></i> إتمام الشراء</h3>

<?php if (!empty($errors)): ?>
  <div class="alert alert-danger">
    <ul class="mb-0"><?php foreach ($errors as $e): ?><li><?php echo htmlspecialchars($e); ?></li><?php endforeach; ?></ul>
  </div>
<?php endif; ?>

<div class="row g-4">
  <div class="col-md-7">
    <div class="card shadow-sm p-4">
      <form method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
        <div class="mb-3">
          <label class="form-label">عنوان الشحن</label>
          <textarea name="address" class="form-control" rows="3" required><?php echo htmlspecialchars($address); ?></textarea>
        </div>
        <div class="mb-3">
          <label class="form-label">رقم الهاتف</label>
          <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($phone); ?>" required>
        </div>
        <button type="submit" class="btn btn-success w-100">تأكيد الطلب</button>
      </form>
    </div>
  </div>

  <div class="col-md-5">
    <div class="card shadow-sm p-4">
      <h5 class="mb-3">ملخص الطلب</h5>
      <?php foreach ($cart_items as $item): ?>
        <div class="d-flex justify-content-between mb-2">
          <span><?php echo htmlspecialchars($item['product']['name']); ?> × <?php echo $item['qty']; ?></span>
          <span><?php echo format_price($item['subtotal']); ?></span>
        </div>
      <?php endforeach; ?>
      <hr>
      <div class="d-flex justify-content-between fw-bold fs-5">
        <span>الإجمالي</span>
        <span class="text-primary"><?php echo format_price($total); ?></span>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
